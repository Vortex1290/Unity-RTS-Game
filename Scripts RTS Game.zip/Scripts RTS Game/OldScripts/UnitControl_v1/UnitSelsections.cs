using System.Collections.Generic;
using UnityEngine;

public class UnitSelsections : MonoBehaviour
{
    public List<GameObject> unitList = new List<GameObject>();
    public List<GameObject> unitsSelected = new List<GameObject>();

    private static UnitSelsections _instance;

    public static UnitSelsections Instance { get { return _instance; } }

    private void Awake()
    {
        {
            if (_instance != null && _instance != this)
            {
                Destroy(this.gameObject);
            }
            else
            {
                _instance = this;
            }
        }
    }
    public void ClickSelect(GameObject UnitToAdd)
    {
        DeselectAll();
        unitsSelected.Add(UnitToAdd);        
        UnitToAdd.transform.GetChild(0).gameObject.SetActive(true);
        UnitToAdd.GetComponent<UnitMovement>().enabled = true;
    }
    public void ShiftClickSelect(GameObject UnitToAdd)
    {
        if (!unitsSelected.Contains(UnitToAdd))
        {

            unitsSelected.Add(UnitToAdd);            
            UnitToAdd.transform.GetChild(0).gameObject.SetActive(true);
            UnitToAdd.GetComponent<UnitMovement>().enabled = true;

        }
        else
        {
            UnitToAdd.GetComponent<UnitMovement>().enabled = false;
            UnitToAdd.transform.GetChild(0).gameObject.SetActive(false);
            unitsSelected.Remove(UnitToAdd);
            

        }
    }
    public void DragSelect(GameObject UnitToAdd)
    {
        if (!unitsSelected.Contains(UnitToAdd))
        {
            unitsSelected.Add(UnitToAdd);
            UnitToAdd.transform.GetChild(0).gameObject.SetActive(true);
            UnitToAdd.GetComponent<UnitMovement>().enabled = true;

        }
    }
    public void DeselectAll()
    {
        foreach (var unit in unitsSelected)
        {
            unit.GetComponent<UnitMovement>().enabled = false;
            //unit.transform.GetChild(0).gameObject.SetActive(false);
            

        }

        unitsSelected.Clear();

    }
    public void Deselect(GameObject UnitToAdd)
    {

    }
}
