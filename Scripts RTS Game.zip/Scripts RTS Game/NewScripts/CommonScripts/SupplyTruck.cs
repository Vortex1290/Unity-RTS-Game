using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditorInternal;
using UnityEngine;

public class SupplyTruck : MonoBehaviour
{
    private bool _inTrigger;

    Enemy enemy;

    FloatingHealthBar healthValue;

    GameObject enemyTag;

    public float healthBonus = 15f;



    void Start()
    {
        //enemy = FindAnyObjectByType<Enemy>();
        //enemy = FindObjectOfType<Enemy>();


    }


    private void Update()
    {
        if (_inTrigger)
        {
            if (enemy.health < enemy.maxHealth)
            {
                enemy.health += healthBonus * Time.deltaTime;
            }
        }
    }


    //--------------------------------------------TARGETER BORDER--------------------------------------------------------------------


    [Tooltip("Sladnik Collider elementu Targeter. Moze byc prostopadloscienna lub kulista bryla ograniczajaca.")]
    public Collider col;

    //Lista wszystkich wrogow w zasiegu wykrywacza:
    [HideInInspector] public List<Enemy> enemies = new List<Enemy>();

    public bool TargetsAreAvailable
    {
        get
        {
            return enemies.Count > 0;

        }

    }

    public void SetRange(int range)
    {
        if (col is BoxCollider)
        {
            //Mnozymy range przez 2, aby wykrywacz siegal na odleglosc
            //'range' jdnostek w kazdym kierunku.
            (col as BoxCollider).size = new Vector3(range * 2, 30, range * 2);
            //Przesowamy polozenie Y srodka w gore o polowe wysokosci:
            (col as SphereCollider).center = new Vector3(0, 15, 0);
        }
        else if (col is SphereCollider)
        {
            //Promien kulistej bryly ograniczajacej jest odlegloscia
            //od srodka do brzegu.
            (col as SphereCollider).radius = range;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        var enemy = other.gameObject.GetComponent<Enemy>();

        if (enemy != null && enemy.health < 48)
        {
            enemies.Add(enemy);
            _inTrigger = true;
            Debug.Log("Leczy");
        }

    }
    void OnTriggerExit(Collider other)
    {
        var enemy = other.gameObject.GetComponent<Enemy>();
        if (enemy != null || enemy.health >= 48)
        {
            enemies.Remove(enemy);
            _inTrigger = false;
            Debug.Log("Naprawiony");

        }
    }


    public Enemy GetClosestEnemy(Vector3 point)
    {
        //Najmniejsza dotychczas znaleziona odleglosc:
        float lowestDistance = Mathf.Infinity;

        //Wrog, dla ktorego wyznaczylismy dotychczas najmniejsza odleglosc:
        Enemy enemyWithLowestDistance = null;

        //Przechodz w petli przez liste wrogow:
        for (int i = 0; i < enemies.Count; i++)
        {
            var enemy = enemies[i]; //Szybkie odwolanie do biezacego wroga

            //Jesli wrog zostal zniszczony lub nie zyje
            if (enemy == null || !enemy.alive)
            {
                //Usun go i kontynuuj petle pod tym samym indeksem:
                enemies.RemoveAt(i);
                i -= 1;
            }
            else
            {
                //Uzyskaj odleglosc od wroga do danego punktu:
                float dist = Vector3.Distance(point, enemy.trans.position);

                if (dist < lowestDistance)
                {
                    lowestDistance = dist;
                    enemyWithLowestDistance = enemy;
                }
            }
        }
        return enemyWithLowestDistance;
    }


    //void OnTriggerEnter(Collider col)
    //{
    //    _inTrigger = true;
    //    Debug.Log("huj0");
    //}

    //private void OnTriggerExit(Collider col)
    //{
    //    _inTrigger = false;
    //    Debug.Log("dupa");
    //}

    //private void OnTriggerEnter(Collider col)
    //{
    //    if (col.gameObject.name.Equals("TestEnemy") && enemy.health < enemy.maxHealth)
    //        StartCoroutine("Heal");
    //}

    //private void OnTriggerExit(Collider col)
    //{
    //    if (col.gameObject.name.Equals("TestEnemy"))
    //        StopCoroutine("Heal");

    //}
    //IEnumerator Heal()
    //{
    //    for (float currenthealth = enemy.health; currenthealth <= 1; currenthealth += 20)
    //    {
    //        enemy.health = currenthealth;
    //        yield return new WaitForSeconds(Time.deltaTime);
    //    }
    //    enemy.health = 1f;
    //}
}












