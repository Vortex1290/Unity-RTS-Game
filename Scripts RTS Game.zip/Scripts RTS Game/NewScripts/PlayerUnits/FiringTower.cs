using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.PackageManager.Requests;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class FiringTower : TargetingTower
{
    [Tooltip("Czy wieza moze atakowac wrogow latajacych?")]
    public bool canAttackFlying = false;

    public bool canHeal = false;

    [Tooltip("Szybkie odwolanie do glownego skladnika Transform wiezy.")]
    public Transform trans;

    [Tooltip("Odwolanie do skladnika Transform, w miejscu ktorego pocisk powinien byc poczatkowo umieszczony.")]
    public Transform projectileSpawnPoint;

    [Tooltip("Odwolanie do skladnika Transform, ktory powinien wskazywac na wroga.")]
    public Transform aimer;

    [Tooltip("Liczba sekund pomiedzy kolejnymi wystrzalami pociskow.")]
    public float fireInterval = .5f;

    [Tooltip("Odwolanie do prefabrykatu pocisku, ktory powinien byc wystrzeliwany.")]
    public Projectile projectilePrefab;

    [Tooltip("Obrazenia zadawane przez kazdy pocisk.")]
    public float damage = 4f;

    [Tooltip("Szybkosc lotu pocisku w jednostkach na sekunde.")]
    public float projectileSpeed = 60;

    private Enemy targetedEnemy;

    [Tooltip("Odwo�anie do po�o�enia podstawowego wie�y.")]
    public Transform BaseTurretPosition;

    [Tooltip("Odwo�anie do po�o�enia dzia�a wie�y.")]
    public Transform BarelPosition;

    private float lastFireTime = Mathf.NegativeInfinity;

    public float rotationSpeed = 0.008f;

    Animator playerAnim;

    Animator tankBarrelAnim;

    public GameObject tankBarrel;


    // Start is called before the first frame update
    void Awake()
    {
        tankBarrelAnim = tankBarrel.GetComponent<Animator>();

        playerAnim = GetComponent<Animator>();
    }

    void Update()
    {
        if (targetedEnemy != null)
        {

            //Jesli ten wrog nie zyje lub jest juz poza zasiegiem,
            //pozyskaj nowy cel:
            if ((!targetedEnemy.alive || Vector3.Distance(trans.position, targetedEnemy.trans.position) > range) && canHeal == false)
            {
                //playerAnim.SetBool("Shoot", false);

                GetNextTarget();

            }








            if ((!targetedEnemy.alive || Vector3.Distance(trans.position, targetedEnemy.trans.position) > range || targetedEnemy.health == targetedEnemy.maxHealth) && canHeal == true) 
            {
                //playerAnim.SetBool("Shoot", false);

                GetNextTarget();

            }
            else //Jesli wrog zyje i jest w zasiegu,
            {
                if (canAttackFlying)
                {
                    //Wyceluj w tego wroga:
                    AimAtTarget();

                    

                    //Sprawdz, czy czas na kolejny wystrzal:
                    if (Time.time > lastFireTime + fireInterval)
                    {
                        Fire();

                        //playerAnim.SetBool("Shoot", true);
                        tankBarrelAnim.SetBool("Barrel Idle", true);
                        tankBarrelAnim.SetBool("Barrel Shoot", true);
                    }
                }                
            }
        }
        //W przeciwnym razie, jesli nie ma namierzonego wroga,
        //a sa dostepne cele
        else if (targeter.TargetsAreAvailable)
        {
            GetNextTarget();

        }
        else if (targetedEnemy == null)
        {
            AimForward();
            tankBarrelAnim.SetBool("Barrel Idle", false);
            tankBarrelAnim.SetBool("Barrel Shoot", false);

        }
    }

    private void AimAtTarget()
    {
        //Jesli element 'aimer' zostal ustawiony, kierujemy go na wroga:
        if (aimer)
        {
            //Ustal polozenie to (do) i from (od),
            //ale ustaw obie wartosci Y na 0:
            Vector3 to = targetedEnemy.transform.position;
            to.y = 0;

            Vector3 from = aimer.position;
            from.y = 0;


            //Uzyskaj obrot, aby patrzec z polozenia 'from'
            //w kierunku polozenia 'to':
            Quaternion desiredRotation = Quaternion.LookRotation((to - from), Vector3.up);

            //Ustawiamy zadany obrot funkcja Slerp:
            aimer.rotation = Quaternion.Slerp(aimer.rotation, desiredRotation, rotationSpeed);

        }
    }

    private void AimForward()
    {
        if (BaseTurretPosition)
        {
            //Ustal polozenie to (do) i from (od),
            //ale ustaw obie wartosci Y na 0:                    

            Vector3 to = BaseTurretPosition.transform.position;
            to.y = 0;

            Vector3 from = aimer.position;
            from.y = 0;

            //Uzyskaj obrot, aby patrzec z polozenia 'from'
            //w kierunku polozenia 'to':
            Quaternion desiredRotation = Quaternion.LookRotation((to - from), Vector3.up);

            //Ustawiamy zadany obrot funkcja Slerp:
            aimer.rotation = Quaternion.Slerp(aimer.rotation, desiredRotation, rotationSpeed);

        }
    }

    private void GetNextTarget()
    {
        targetedEnemy = targeter.GetClosestEnemy(trans.position);
    }
    private void Fire()
    {
        //Zapamietaj czas wystrzalu:
        lastFireTime = Time.time;

        //Wygeneruj pocisk z prefabrykatu w punkcie generowania pociskow:
        var proj = Instantiate<Projectile>(projectilePrefab, projectileSpawnPoint.position, projectileSpawnPoint.rotation);



        //Ustaw obrazenia, predkosc i cel dla pocisku:
        proj.Setup(damage, projectileSpeed, targetedEnemy);

    }
}

