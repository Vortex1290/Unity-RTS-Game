using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerUnit : MonoBehaviour
{
    [Header("References")]
    public Transform trans;
    public Transform projectileSeekPoint;

    [Header("Stats")]
    public float maxHealth;
    [HideInInspector] public float health;

    [HideInInspector] public bool alive = true;

    protected virtual void Start()
    {
        health = maxHealth;
    }

    public void TakeDamage(float amount)
    {
        //Idz dalej, jesli otrzymano wiecej niz 0 obrazen:
        if (amount > 0)
        {
            //Obniz health o 'amount' ale nie schodz ponizej 0:
            health = Mathf.Max(health - amount, 0);

            //Jesli cale zdrowie zostalo stracone,
            if (health == 0)
            {
                //wywolaj Die:
                Die();
            }
        }
    }
    public void Die()
    {
        if (alive)
        {
            alive = false;
            Destroy(gameObject);
        }
    }

}
