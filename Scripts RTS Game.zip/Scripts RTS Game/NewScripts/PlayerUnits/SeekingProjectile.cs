using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeekingProjectile : Projectile
{
    [Header("References")]
    public Transform trans;

    //Zmienne prywatne:
    private Vector3 targetPosition;

    public void Update()
    {
        if (targetEnemy != null)
        {
            //Zapamietaj ostatnie polozenie wroga:
            targetPosition = targetEnemy.projectileSeekPoint.position;
        }
        
        //Ustaw sie w kierunku polozenia celu:
        trans.forward = (targetPosition - trans.position).normalized;

        //Przesun sie w kierunku polozenia celu:
        trans.position = Vector3.MoveTowards(trans.position, targetPosition, speed * Time.deltaTime);
        //Jesli dotarlismy do polozenia docelowego,
        if (trans.position == targetPosition)
        {
            //Zniszcz wroga, jesli nadal istnieje:
            if (targetEnemy != null)            
                targetEnemy.TakeDamage(damage);
                //Zniszcz pocisk:
                Destroy(gameObject);
            
        }
    }
    protected override void OnSetup()
    {

    }    
}

