using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoldierAnimationScript : MonoBehaviour
{
    Animator playerAnim;

    // Start is called before the first frame update
    void Start()
    {
        playerAnim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (playerAnim != null)
        {
            //if (Input.GetKeyUp(KeyCode.Q))
            //{
            //    playerAnim.SetTrigger("TrIdle");
            //}

            //if (Input.GetKeyUp(KeyCode.W)) 
            //{
            //    playerAnim.SetTrigger("TrRun");
            //}

            //if (Input.GetKeyUp(KeyCode.R))
            //{
            //    playerAnim.SetTrigger("TrShoot");
            //}

            if (Input.GetKeyDown(KeyCode.Q))
            {
                print("Stop");
                playerAnim.SetBool("Run", false);
                playerAnim.SetBool("Shoot", false);
            }
            if (Input.GetKeyDown(KeyCode.W))
            {
                print("Run");
                playerAnim.SetBool("Run", true);
            }
            if (Input.GetKeyDown(KeyCode.R))
            {
                print("Shoot");
                playerAnim.SetBool("Shoot", true);
            }
        }
      
    }
}
