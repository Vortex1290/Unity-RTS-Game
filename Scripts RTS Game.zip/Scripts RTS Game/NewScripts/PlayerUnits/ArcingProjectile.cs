using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArcingProjectile : Projectile
{
    public Transform trans;

    [Tooltip("Maska warstw uzywana przy wykrywaniu wrogow, na ktorych wplynie wybuch.")]
    public LayerMask enemyLayerMask;

    [Tooltip("Promien wybuchu.")]
    public float explosionRadius = 25;

    [Tooltip("Krzywa przechodzaca od wartosci 0 do 1 przez 1 sekunde. Definiuje krzywa lotu pocisku")]
    public AnimationCurve curve;

    //Polozenie, w ktore celujemy. Wartosc Y bedzie zawsze rowna 0.
    private Vector3 targetPosition;

    //Nasze polozenie przy wygenerowaniu.
    private Vector3 initialPosition;

    //Calkowita odleglosc od polozenia poczatkowego do docelowego
    //z pominieciem osi Y.

    private float xzDistanceToTravel;

    //Czas Time.time wygenerowania pocisku.
    private float spawnTime;

    private float FractionOfDistanceTraveled
    {
        get
        {
            float timeSinceSpwan = Time.time - spawnTime;
            float timeToReachDestination = xzDistanceToTravel / speed;

            return timeSinceSpwan / timeToReachDestination;
        }
    }

    protected override void OnSetup()
    {
        //Ustaw poczatkowe polozenie na nasze biezace polozenie,
        //a polozenie docelowe na polozenie docelowego wroga:
        initialPosition = trans.position;
        targetPosition = targetEnemy.trans.position;

        //Upewnijmy sie, ze polozenie docelowe zawsze ma wspolrzedna Y
        //rowna 0;
        targetPosition.y = 5;

        //Oblicz calkowita odleglosc, jaka musimy przebyc na osiach X i Z:
        xzDistanceToTravel = Vector3.Distance(new Vector3(trans.position.x, targetPosition.y, trans.position.z), targetPosition); ;

        //Zapamietaj czas Time.time wygenerowania pocisku:
        spawnTime = Time.time;
    }
    void Update()
    {
        //Najpierw wykonaj ruch wzdluz osi X i Z.
        //Pobierz aktualne polozenie i wyzeruj wspolrzedna Y:
        Vector3 currentPosition = trans.position;
        currentPosition.y = 0;

        //Przemieszczaj biezace polozenie w kierunku polozenia docelowego
        //z predkoscia 'speed' na sekunde:
        currentPosition = Vector3.MoveTowards(currentPosition, targetPosition, speed * Time.deltaTime);

        //Teraz ustaw wspolrzedna Y dla currentPosition:
        currentPosition.y = Mathf.Lerp(initialPosition.y, targetPosition.y *3, curve.Evaluate(FractionOfDistanceTraveled));

        //Zastosuj polozenie wobec skladnika Transform:
        trans.position = currentPosition;

        //Uruchom wybuch, jesli dotarlismy do polozenia docelowego:
        if (currentPosition == targetPosition)
        {
            Explode();
        }
    }
    private void Explode()
    {
        Collider[] enemyColliders = Physics.OverlapSphere(trans.position, explosionRadius, enemyLayerMask.value);

        //Przejdz w petli przez bryly ograniczajace wrogow:
        for (int i = 0; i < enemyColliders.Length; i++)
        {

            //Uzyskaj skladnik skryptu Enemy:
            var enemy = enemyColliders[i].GetComponent<Enemy>();

            //Jesli znaleziono skladnik Enemy:
            if (enemy != null)
            {
                float distToEnemy = Vector3.Distance(trans.position, enemy.trans.position);

                float damageToDeal = damage * (1 - Mathf.Clamp(distToEnemy / explosionRadius, 0f, 1f));
                enemy.TakeDamage(damageToDeal);
            }
        }
        Destroy(gameObject);
    }

   
}
