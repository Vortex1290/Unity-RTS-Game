using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class Player : MonoBehaviour
{
    [Header("References")]
    public Transform trans;

    [Header("X Bounds")]
    public float minimumX = -70;
    public float maximumX = 70;

    [Header("Y Bounds")]
    public float minimumY = 18;
    public float maximumY = 80;

    [Header("Z Bounds")]
    public float minimumZ = -130;
    public float maximumZ = 70;

    [Header("Movement")]
    [Tooltip("Odleglosc pokonywaba w ciagu sekundy ruchu wywolanego przez klawisze ze strzalkami.")]
    public float arrowKeySpeed = 80;

    [Tooltip("Mnoznik dla ruchu przez przeciaganie mysza. Wyzsza wartosc spowoduje ruch kamery na wieksza doleglosc przy ruchu mysza")]
    public float mouseDragSensitivity = 2.8f;

    [Tooltip("Wielkosc wygladzania stosowana  wobec ruchu kamry. Powinna byc wartosc pomiedzy 0 a 1")]
    [Range(0, .99f)]
    public float movementSmoothing = .75f;

    private Vector3 targetPosition;

    [Header("Scrolling")]
    [Tooltip("Wielkosc odleglosci Y pokonywanej przez kamere przy jednostce obrotu kolka myszy.")]
    public float scrollSensitivity = 1.6f;

    [Header("Camera rotation")]
    public float rotateSpeed = 0.1f;

    Vector2 p1;
    Vector2 p2;

    void ArrowKeyMovement()
    {
        //Jesli wcisnieta jest strzalka w gore,
        if (Input.GetKey(KeyCode.UpArrow))
        {
            //...zwiekszamy wpolrzedna z polozenia doceloweg:
            targetPosition.z += arrowKeySpeed * Time.deltaTime;
        }
        //W przeciwnym wypadku , jesli wcisnieta jest strzalka w dol,
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            //...zmniejszamy wpolrzedna Z polozenia docelowego :
            targetPosition.z -= arrowKeySpeed * Time.deltaTime;
        }
        //Jesli wcisnieta jest strzalka w prawo,
        if (Input.GetKey(KeyCode.RightArrow))
        {
            //...zwiekszamy wspolrzedna X polozenia docelowego:
            targetPosition.x += arrowKeySpeed * Time.deltaTime;
        }
        //W przeciwnym razie , jesli wcisnieta jest strzalka w lewo,
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            //zmniejszamy wspolrzedna X polozenia docelowrgo:
            targetPosition.x -= arrowKeySpeed * Time.deltaTime;
        }

        //float speed = 0.5f;

        //float hsp = transform.position.y * speed * Input.GetAxis("Horizontal");
        //float vsp = transform.position.y * speed * Input.GetAxis("Vertical");


        //Vector3 lateralMove = hsp * transform.right;
        //Vector3 forwardMove = transform.forward;

        //forwardMove.y = 0;
        //forwardMove.Normalize();
        //forwardMove *= vsp;

        //Vector3 move = lateralMove + forwardMove;

        //transform.position += move;
    }


    //Malo potrzebna metoda----------------------------------------------------------
    void MouseDragMovement()
    {
        //Jesli wcisniety jest prawy przycisk myszy, 
        if (Input.GetMouseButton(1))
        {
            //Uzyskaj wielkosc ruchu tej klatki:
            Vector3 movement = new Vector3(-Input.GetAxis("Mouse X"), 0, -Input.GetAxis("Mouse Y")) * mouseDragSensitivity;

            //Jesli jest jakikolwiek ruch,
            if (movement != Vector3.zero)
            {
                //...zastosuj go wobec targetPosition:
                targetPosition += movement;
            }
        }
    }
    //-----------------------------------------------------------------------------------
    void Zooming()
    {
        //Uzyskaj wartosc delta Y dla obracania kolka myszy i odwroc ja:
        float scrollDelta = -Input.mouseScrollDelta.y;

        //Jesli bylo jakies obrocenie kolka myszy,
        if (scrollDelta != 0)
        {
            //...zastosuj to wobec polozenia Y:
            targetPosition.y += scrollDelta * scrollSensitivity;
        }
    }
    void MoveTowardsTarget()
    {
        //Zmiesc polozenie docelowe pomiedzy zmiennymi ograniczajacymi:
        targetPosition.x = Mathf.Clamp(targetPosition.x, minimumX, maximumX);
        targetPosition.y = Mathf.Clamp(targetPosition.y, minimumY, maximumY);
        targetPosition.z = Mathf.Clamp(targetPosition.z, minimumZ, maximumZ);

        //Wykonaj ruch, jesli nie jestesmy w polozeniu docelowym:

        if (trans.position != targetPosition)
        {
            trans.position = trans.position = Vector3.Lerp(trans.position, targetPosition, 1 - movementSmoothing);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        targetPosition = trans.position;
    }

    // Update is called once per frame
    void Update()
    {
        ArrowKeyMovement();
        MouseDragMovement();
        Zooming();
        MoveTowardsTarget();
        getCameraRotation();
    }
    void getCameraRotation()
    {
        if (Input.GetMouseButtonDown(2))
        {
            p1 = Input.mousePosition;
        }
        else if (Input.GetMouseButton(2))
        {
            p2 = Input.mousePosition;

            float dx = (p2 - p1).x * rotateSpeed;
            float dy = (p2 - p1).y * rotateSpeed;

            transform.rotation *= Quaternion.Euler(new Vector3(0, dx, 0));
            transform.GetChild(0).transform.rotation *= Quaternion.Euler(new Vector3(-dy, 0, 0));

            p1 = p2;
        }
    }
    //***************************************************************************************************

    private enum Mode
    {
        Build,
        Play
    }
    private Mode mode = Mode.Build;

    [Header("Build Mode")]
    [Tooltip("Maska warstw dla rzutowania promienia. Powinna obejmowac warstwe z obszarem gry.")]
    public LayerMask stageLayerMask;

    [Tooltip("Odwolanie do skladnika Transform elementu Highlighter.")]
    public Transform highlighter;

    [Tooltip("Odwolanie do elementu Tower Selling Panel.")]
    public RectTransform towerSellingPanel;

    [Tooltip("Odwolanie do skladnika Text elementu Refund Text w Tower Selling Panel")]
    public Text sellRefundText;

    [Tooltip("Odwolanie do skladnika Text tekstu wyswietlajacego aktualna ilosc zlota w lewym dolnym rogu interfejsu uzytkownika.")]
    public Text currentGoldText;

    [Tooltip("Kolor uzywany wobec zaznaczonego przyciku budowania.")]
    public Color selectBuildButtonColor = new Color(.2f, .8f, .2f);

    //Polozenie myszy w ostatniej klatce.
    private Vector3 lastMousePosition;

    //Aktualna ilosc zlota przy ostatnim sprawdzaniu.
    private int goldLastFrame;

    //Wartosc true, jesli kursor jest obecnie nad obszarem gry,
    //false w przeciwnym razie.
    private bool cursorIsOverStage = false;

    //Odwolanie do prefabrykatu Tower wybranego przez przycisk budowania.
    private Enemy towerPrefabToBuild = null;

    //Aktualnie zaznaczone wystapienie wiezy, jesli istnieje.
    private Enemy selectedTower = null;

}
