using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTargeting : MonoBehaviour
{
    public EnemyTargeter targeter;
    public int range = 45;

    protected virtual void Start()
    {
        targeter.SetRange(range);
    }
}
