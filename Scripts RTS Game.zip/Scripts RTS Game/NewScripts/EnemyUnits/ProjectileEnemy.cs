using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ProjectileEnemy : MonoBehaviour
{
    [HideInInspector] public float damage;
    [HideInInspector] public float speed;
    [HideInInspector] public PlayerUnit targetedEnemy;

    public void Setup(float damage, float speed, PlayerUnit targetedEnemy)
    {
        this.damage = damage;
        this.speed = speed;
        this.targetedEnemy = targetedEnemy;

        OnSetup();
    }
    protected abstract void OnSetup();
}
