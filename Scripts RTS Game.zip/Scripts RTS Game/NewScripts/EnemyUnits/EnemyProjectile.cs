using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class EnemyProjectile : MonoBehaviour
{
    [HideInInspector] public float damage;
    [HideInInspector] public float speed;
    [HideInInspector] public PlayerUnit targetEnemy;

    public void Setup(float damage, float speed, PlayerUnit targetEnemy)
    {
        this.damage = damage;
        this.speed = speed;
        this.targetEnemy = targetEnemy;

        OnSetup();
    }
    protected abstract void OnSetup();
}
