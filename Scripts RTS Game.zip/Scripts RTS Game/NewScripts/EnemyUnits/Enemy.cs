using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{

    [Header("References")]
    public Transform trans;
    public Transform projectileSeekPoint;

    [Header("Stats")]
    public float maxHealth;
    public float health;

    [HideInInspector] public bool alive = true;

    [SerializeField] FloatingHealthBar healthBar;

    public GameObject fire;
    public GameObject healing;
    public GameObject player;



    private void Awake()
    {
        healthBar = GetComponentInChildren<FloatingHealthBar>();
        healing = GameObject.FindWithTag("Healing");

    }


    protected virtual void Start()
    {
        health = maxHealth;
        //healthBar.UpdateHealthBar(health, maxHealth);

    }

    private void Update()
    {
        healthBar.UpdateHealthBar(health, maxHealth);


    }
    public void TakeDamage(float amount)
    {

        //Idz dalej, jesli otrzymano wiecej niz 0 obrazen:
        if (amount > 0)
        {

            //Obniz health o 'amount' ale nie schodz ponizej 0:
            health = Mathf.Max(health - amount, 0);

            healthBar.UpdateHealthBar(health, maxHealth);
        }
        if (amount < 0)
        {

            //Obniz health o 'amount' ale nie schodz ponizej 0:
            health = Mathf.Min(health - amount, maxHealth);

            healthBar.UpdateHealthBar(health, maxHealth);

        }

        //Jesli cale zdrowie zostalo stracone,
        if (health == 0)
        {
            //wywolaj Die:
            Die();
        }
        
    }


    public void Die()
    {
        if (alive)
        {
            alive = false;
            fire.SetActive(true);

            Destroy(GetComponent<Enemy>());
            Destroy(GetComponent<Unit>());
            Destroy(GetComponent<UnitMovement>());
            Destroy(GetComponent<NavMeshAgent>());
        }
    }
}
