using System.Collections;
using System.Collections.Generic;
using UnityEditor.PackageManager.Requests;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class EnemyFiringTower : EnemyTargeting
{
    [Tooltip("Czy wieza moze atakowac wrogow latajacych?")]
    public bool canAttackFlying = true;

    [Tooltip("Szybkie odwolanie do glownego skladnika Transform wiezy.")]
    public Transform trans;

    [Tooltip("Odwolanie do skladnika Transform, w miejscu ktorego pocisk powinien byc poczatkowo umieszczony.")]
    public Transform projectileSpawnPoint;

    [Tooltip("Odwolanie do skladnika Transform, ktory powinien wskazywac na wroga.")]
    public Transform aimer;

    [Tooltip("Liczba sekund pomiedzy kolejnymi wystrzalami pociskow.")]
    public float fireInterval = .5f;

    [Tooltip("Odwolanie do prefabrykatu pocisku, ktory powinien byc wystrzeliwany.")]
    public EnemyProjectile projectilePrefab;

    [Tooltip("Obrazenia zadawane przez kazdy pocisk.")]
    public float damage = 4;

    [Tooltip("Szybkosc lotu pocisku w jednostkach na sekunde.")]
    public float projectileSpeed = 60;

    private PlayerUnit targetedEnemy;

    [Tooltip("Odwo�anie do po�o�enia podstawowego wie�y.")]
    public Transform BaseTurretPosition;

    [Tooltip("Odwo�anie do po�o�enia dzia�a wie�y.")]
    public Transform BarelPosition;

    private float lastFireTime = Mathf.NegativeInfinity;

    public float rotationSpeed = 0.008f;



    void Update()
    {
        if (targetedEnemy != null)
        {
            //Jesli ten wrog nie zyje lub jest juz poza zasiegiem,
            //pozyskaj nowy cel:
            if (!targetedEnemy.alive || Vector3.Distance(trans.position, targetedEnemy.trans.position) > range)
            {
                GetNextTarget();
            }
            else //Jesli wrog zyje i jest w zasiegu,
            {
                //Wyceluj w tego wroga:
                AimAtTarget();

                //Sprawdz, czy czas na kolejny wystrzal:
                if (Time.time > lastFireTime + fireInterval)
                {
                    Fire();

                }
            }
        }
        //W przeciwnym razie, jesli nie ma namierzonego wroga,
        //a sa dostepne cele
        else if (targeter.TargetsAreAvailable)
        {
            GetNextTarget();

        }
        else if (targetedEnemy == null)
        {
            AimForward();
        }


    }

    private void AimAtTarget()
    {
        //Jesli element 'aimer' zostal ustawiony, kierujemy go na wroga:
        if (aimer)
        {
            //Ustal polozenie to (do) i from (od),
            //ale ustaw obie wartosci Y na 0:
            Vector3 to = targetedEnemy.transform.position;
            to.y = 0;

            Vector3 from = aimer.position;
            from.y = 0;


            //Uzyskaj obrot, aby patrzec z polozenia 'from'
            //w kierunku polozenia 'to':
            Quaternion desiredRotation = Quaternion.LookRotation((to - from), Vector3.up);

            //Ustawiamy zadany obrot funkcja Slerp:
            aimer.rotation = Quaternion.Slerp(aimer.rotation, desiredRotation, rotationSpeed);

        }
    }

    private void AimForward()
    {
        if (BaseTurretPosition)
        {
            //Ustal polozenie to (do) i from (od),
            //ale ustaw obie wartosci Y na 0:



            Vector3 to = BaseTurretPosition.transform.position;
            to.y = 0;

            Vector3 from = aimer.position;
            from.y = 0;

            //Uzyskaj obrot, aby patrzec z polozenia 'from'
            //w kierunku polozenia 'to':
            Quaternion desiredRotation = Quaternion.LookRotation((to - from), Vector3.up);

            //Ustawiamy zadany obrot funkcja Slerp:
            aimer.rotation = Quaternion.Slerp(aimer.rotation, desiredRotation, rotationSpeed);

        }
    }

    private void GetNextTarget()
    {
        targetedEnemy = targeter.GetClosestEnemy(trans.position);
    }
    private void Fire()
    {
        //Zapamietaj czas wystrzalu:
        lastFireTime = Time.time;

        //Wygeneruj pocisk z prefabrykatu w punkcie generowania pociskow:
        var proj = Instantiate<EnemyProjectile>(projectilePrefab, projectileSpawnPoint.position, projectileSpawnPoint.rotation);

        //Ustaw obrazenia, predkosc i cel dla pocisku:
        proj.Setup(damage, projectileSpeed, targetedEnemy);
    }


}

